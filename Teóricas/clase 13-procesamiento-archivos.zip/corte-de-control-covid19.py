import csv

def main():
    with open("datasets/covid19/covid19.csv") as f:
        mes = None
        dia = None

        confirmados_mes = 0
        confirmados_dia = 0

        confirmados = 0

        for caso in csv.DictReader(f):
            fecha = caso['fecha_apertura']
            if not fecha:
                continue
            if caso['clasificacion_resumen'].lower() != 'confirmado':
                continue
            año, mes_caso, dia_caso = [int(x) for x in fecha.split('-')]
            if dia_caso != dia or mes_caso != mes:
                resumen_dia(mes, dia, confirmados_dia)
                dia = dia_caso
                confirmados_dia = 0
            if mes_caso != mes:
                resumen_mes(mes, confirmados_mes)
                mes = mes_caso
                confirmados_mes = 0
            confirmados_dia += 1
            confirmados_mes += 1
            confirmados += 1
        resumen_dia(mes, dia, confirmados_dia)
        resumen_mes(mes, confirmados_mes)
        print(f"total: {confirmados=}")

def resumen_dia(mes, dia, confirmados_dia):
    #if dia:
    #    print(f'{dia}/{mes}: {confirmados_dia}')
    pass

def resumen_mes(mes, confirmados_mes):
    if mes:
        print(f'total mes {mes}: {confirmados_mes}')

main()
