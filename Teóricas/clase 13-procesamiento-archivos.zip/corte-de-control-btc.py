import csv

def corte_control_btc():
    """
    A partir del archivo btc.csv, imprime totales y máximos por mes, año y global
    """
    with open('datasets/btc/btc.csv') as f:
        r = csv.reader(f)
        # saltear el encabezado
        next(r)

        fila = next(r, None)
        total = 0
        total_max = 0
        while fila:
            year = fila[0]
            year_total = 0
            year_max = 0
            while fila and fila[0] == year:
                month = fila[1]
                month_total = 0
                month_max = 0
                while fila and fila[0] == year and fila[1] == month:
                    vol = float(fila[-3])
                    high = float(fila[6])
                    month_total += vol
                    month_max = max(month_max, high)

                    fila = next(r, None)
                print(f'total {year}/{month}: {month_total:.2f}, max: {month_max:.2f}')
                year_total += month_total
                year_max = max(year_max, month_max)
            print(f'total {year}: {year_total:.2f}, max: {year_max:.2f}')
            total += year_total
            total_max = max(total_max, year_max)

        print(f'total: {total:.2f}, max: {total_max:.2f}')

corte_control_btc()
