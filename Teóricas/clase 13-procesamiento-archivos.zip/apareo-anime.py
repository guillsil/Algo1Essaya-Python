import csv

def apareo_anime():
    """
    A partir de los archivos anime.csv con los títulos, y ratings.csv con el voto de
    cada usuario, imprime: "titulo - promedio - (cant. de votos)"
    """
    with open('datasets/anime/anime.csv') as anime, open('datasets/anime/rating.csv') as rating:
        csv_anime = csv.reader(anime)
        csv_rating = csv.reader(rating)

        # saltear los encabezados
        next(csv_anime)
        next(csv_rating)

        fila_anime = next(csv_anime, None)
        fila_rating = next(csv_rating, None)

        while fila_anime:
                anime_id = fila_anime[0]
                anime_nombre = fila_anime[1]

                cantidad = 0
                suma = 0

                while fila_rating and fila_rating[1] == anime_id:
                    voto = int(fila_rating[2])
                    if voto != -1:
                        cantidad += 1
                        suma += voto
                    fila_rating = next(csv_rating, None)

                if cantidad > 0:
                    print(f"{anime_nombre}: {suma/cantidad:.2f} ({cantidad})")
                else:
                    print(f"{anime_nombre}: (no tiene votos)")

                fila_anime = next(csv_anime, None)

apareo_anime()
